# CarScout Real-Inventory Architecture

This version adds:
- Express backend API
- `/api/listings` inventory endpoint
- `/api/listings/:id` listing pages
- `/api/vehicles/:slug` vehicle-page endpoint
- Server-side provider boundary so API keys are not exposed to browsers
- Search by make/model/price/mileage/distance
- Individual listing pages
- Demo inventory that is explicitly not presented as live inventory

## Run locally
1. Install Node.js 20+.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Run `npm start`.
6. Open http://localhost:3000

## Connecting real inventory
The demo adapter in `server.js` is intentionally separate from the website. Replace it with an inventory provider/API for which you have permission to display listings. Put provider credentials in `.env` and make requests from the server, never from browser JavaScript.

Do not scrape dealer sites, KBB, Autotrader, Cars.com, CarGurus, or other sites unless their terms/license explicitly allow your intended use. Use an authorized feed, API, syndication agreement, or dealer data partnership.

## KBB
KBB valuation data should be connected only through a commercial agreement/API/syndication arrangement that permits your intended display. This project does not contain KBB data or pretend to have KBB access.

## Production checklist
- Obtain an inventory data license/feed.
- Obtain valuation data rights if using KBB or another provider.
- Add a real database (Postgres/Supabase/etc.) if storing inventory.
- Add scheduled inventory refreshes and remove sold/stale listings.
- Add source attribution and required disclosures.
- Add privacy policy, terms, cookie/consent handling, analytics, and ad-network compliance.
- Add rate limiting, validation, caching, error monitoring, and HTTPS.
