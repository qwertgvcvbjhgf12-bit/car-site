import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { inventory } from './data/inventory.js';

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json());
app.use(express.static(path.join(__dirname,'public')));

// Demo adapter. Replace this with a licensed inventory feed/provider.
function searchInventory(q={}) {
  const maxPrice = Number(q.maxPrice || Infinity);
  const maxMiles = Number(q.maxMiles || Infinity);
  const radius = Number(q.radius || Infinity);
  return inventory.filter(v =>
    (!q.make || v.make.toLowerCase()===q.make.toLowerCase()) &&
    (!q.model || v.model.toLowerCase()===q.model.toLowerCase()) &&
    (!q.body || v.body===q.body) &&
    (!q.zip || !radius || v.distanceMiles<=radius) &&
    v.price<=maxPrice && v.mileage<=maxMiles
  );
}

app.get('/api/health',(req,res)=>res.json({ok:true,mode: process.env.INVENTORY_API_BASE_URL?'licensed-provider':'demo-data'}));
app.get('/api/cars',(req,res)=>{
  const cars = [...new Map(searchInventory(req.query).map(v=>[v.year+'-'+v.make+'-'+v.model,v])).values()];
  res.json({count:cars.length, cars});
});
app.get('/api/listings',(req,res)=>res.json({count:searchInventory(req.query).length,listings:searchInventory(req.query)}));
app.get('/api/listings/:id',(req,res)=>{
  const listing=inventory.find(v=>v.id===req.params.id);
  if(!listing) return res.status(404).json({error:'Listing not found'});
  res.json(listing);
});
app.get('/api/vehicles/:slug',(req,res)=>{
  const decoded=req.params.slug.toLowerCase();
  const matches=inventory.filter(v=>`${v.year}-${v.make}-${v.model}`.toLowerCase().replaceAll(' ','-')===decoded);
  if(!matches.length) return res.status(404).json({error:'Vehicle page not found'});
  const first=matches[0];
  res.json({vehicle:{year:first.year,make:first.make,model:first.model,body:first.body,mpg:first.mpg}, listings:matches});
});

// Provider boundary: keep third-party credentials server-side.
app.get('/api/provider-status',(req,res)=>res.json({
  inventoryProvider: process.env.INVENTORY_API_BASE_URL?'configured':'not-configured',
  valuationProvider: process.env.KBB_API_BASE_URL?'configured':'not-configured',
  note:'Configure only providers whose terms/license permit your intended use.'
}));

app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`CarScout running at http://localhost:${PORT}`));
